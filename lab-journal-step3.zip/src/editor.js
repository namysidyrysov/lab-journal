// Редактор: одна длинная страница, оглавление слева, автосохранение в папку проекта.

const Editor = (() => {
  const $ = id => document.getElementById(id);
  const doc = $('doc'), T = $('T'), S = $('S'), esc = LJ.esc;
  const q = (b, s) => b.querySelector(s).textContent.trim();
  const ed = { dir: null, ver: 0, saving: false, again: false, timer: null, lastText: null, lastBackup: 0 };
  let rng = null, tocTimer = null;
  document.execCommand('defaultParagraphSeparator', false, 'p');

  // ---------- блоки ----------
  const arm = r => r.querySelectorAll('.ed').forEach(e => e.contentEditable = true);
  // Пути картинок прячем в data-path ещё до вставки в страницу, чтобы браузер не искал их рядом с редактором.
  function pre(html) {
    const t = document.createElement('template');
    t.innerHTML = html || '';
    t.content.querySelectorAll('img').forEach(i => {
      const p = i.getAttribute('src') || '';
      if (p.startsWith('images/')) { i.dataset.path = p; i.removeAttribute('src'); }
    });
    return t.innerHTML;
  }
  const FX = '<button class="fx" contenteditable="false" title="Удалить картинку">×</button>';

  // В конце ячейки всегда должна быть строка, куда можно поставить курсор.
  function tail(body) {
    const l = body.lastElementChild;
    if (!l || l.tagName === 'FIGURE') body.insertAdjacentHTML('beforeend', '<p><br></p>');
  }
  function wire(b) {
    arm(b);
    b.querySelectorAll('figure').forEach(f => { if (!f.querySelector('.fx')) f.insertAdjacentHTML('beforeend', FX); });
    b.querySelectorAll('.body').forEach(tail);
    const exp = b.classList.contains('exp');
    b.insertAdjacentHTML('afterbegin', '<div class="tools" contenteditable="false">' +
      (exp ? '<button data-a="addc">+ колонка</button><button data-a="delc">− колонка</button>' : '') +
      '<button data-a="up">↑</button><button data-a="down">↓</button><button data-a="del">✕</button></div>');
    return b;
  }
  function mkExp(o) {
    const b = document.createElement('section');
    b.className = 'blk exp'; b.dataset.id = o.id || LJ.uid();
    b.innerHTML = `<div class="exp-h"><strong class="ed plain t" data-ph="Название">${esc(o.title)}</strong>&nbsp;&nbsp;&nbsp;&nbsp; Дата: <span class="ed plain d" data-ph="дата">${esc(o.date)}</span></div>` +
      `<div class="cols" style="--n:${o.columns.length}">` +
      o.columns.map(c => `<div class="col"><div class="lbl ed plain" data-ph="Колонка">${esc(c.title)}</div><div class="body ed">${pre(c.html)}</div></div>`).join('') + '</div>';
    return wire(b);
  }
  function mkText(o) {
    const b = document.createElement('section');
    b.className = 'blk txt'; b.dataset.id = o.id || LJ.uid();
    b.innerHTML = `<div class="body ed">${pre(o.html)}</div>`;
    return wire(b);
  }
  const today = () => new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' }).replace(/\s?г\.$/, '');
  function newExp() {
    const exps = doc.querySelectorAll('.exp'), last = exps[exps.length - 1];
    const titles = last ? [...last.querySelectorAll('.lbl')].map(l => l.textContent.trim()) : LJ.DEFAULT_COLUMNS;
    return mkExp({ title: `Эксперимент № ${exps.length + 1}`, date: today(), columns: titles.map(t => ({ title: t, html: '' })) });
  }
  function add(b) {
    const cur = rng && (rng.startContainer.nodeType === 1 ? rng.startContainer : rng.startContainer.parentElement)?.closest('.blk');
    cur && doc.contains(cur) ? cur.after(b) : doc.append(b);
    (b.querySelector('.t') || b.querySelector('.body')).focus();   // курсор в новый блок
    b.scrollIntoView({ block: 'center' });
    touch(); toc();
  }

  // ---------- картинки ----------
  // На экране картинка — blob-ссылка, а настоящий путь (images/...) лежит в data-path.
  async function loadImages(root) {
    await Promise.all([...root.querySelectorAll('img')].map(async img => {
      const p = img.dataset.path || '';
      if (!p) return;
      const f = await LJ.disk.file(ed.dir, p);
      if (f) img.src = URL.createObjectURL(f); else img.alt = 'файл не найден: ' + p;
    }));
  }
  async function addImage(file) {
    const ext = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp' }[file.type] || 'png';
    const path = `images/img-${LJ.disk.stamp()}-${LJ.uid().slice(0, 4)}.${ext}`;
    await LJ.disk.write(ed.dir, path, file);      // на диск сразу, не при сохранении
    return `<figure><img data-path="${path}" src="${URL.createObjectURL(file)}" alt=""><figcaption>Подпись</figcaption>${FX}</figure>`;
  }
  function ins(html) {
    const n = rng && (rng.startContainer.nodeType === 1 ? rng.startContainer : rng.startContainer.parentElement);
    const body = n?.closest('.body.ed');
    if (!body) { alert('Сначала поставьте курсор в нужную колонку.'); return; }
    body.focus();
    const s = getSelection(); s.removeAllRanges(); s.addRange(rng);
    document.execCommand('insertHTML', false, html);
    tail(body);
  }

  // ---------- данные ----------
  function clean(body) {
    const c = body.cloneNode(true);
    c.querySelectorAll('.fx').forEach(x => x.remove());
    // Путь подставляем в текст, а не в элемент: иначе браузер попытается загрузить картинку из копии.
    c.querySelectorAll('img[data-path]').forEach(i => { i.setAttribute('data-lj-src', i.dataset.path); i.removeAttribute('data-path'); i.removeAttribute('src'); });
    c.querySelectorAll('[contenteditable]').forEach(x => x.removeAttribute('contenteditable'));
    for (let l = c.lastElementChild; l && l.tagName === 'P' && !l.textContent.trim() && !l.querySelector('img'); l = c.lastElementChild) l.remove();
    return LJ.tidy(c.innerHTML.replace(/ data-lj-src=/g, ' src='));
  }
  function collect() {
    const data = { version: LJ.VERSION, title: T.textContent.trim(), subtitle: S.textContent.trim(), blocks: [] };
    doc.querySelectorAll(':scope>.blk').forEach(b => {
      const id = b.dataset.id;
      if (b.classList.contains('exp')) data.blocks.push({ id, type: 'experiment', title: q(b, '.t'), date: q(b, '.d'),
        columns: [...b.querySelectorAll('.col')].map(c => ({ title: q(c, '.lbl'), html: clean(c.querySelector('.body')) })) });
      else data.blocks.push({ id, type: 'text', html: clean(b.querySelector('.body')) });
    });
    return data;
  }

  // ---------- сохранение ----------
  const DK = 'lj-draft';
  const draft = (on, data) => { try { on ? localStorage.setItem(DK, JSON.stringify({ project: ed.dir.name, at: Date.now(), data })) : localStorage.removeItem(DK); } catch { } };
  function setSt(t, cls) { $('st').textContent = t; $('st').className = cls || ''; }
  function touch() {
    ed.ver++; setSt('Изменения…');
    clearTimeout(ed.timer); ed.timer = setTimeout(save, 1500);
    clearTimeout(tocTimer); tocTimer = setTimeout(toc, 400);
  }
  async function save() {
    if (!ed.dir) return;
    clearTimeout(ed.timer);
    if (ed.saving) { ed.again = true; return; }
    ed.saving = true;
    const v = ed.ver;
    try {
      const data = collect();
      draft(true, data);                           // запасной вариант, если запись на диск не удастся
      const html = LJ.serialize(data);
      // Копия предыдущей версии: при первом сохранении за сеанс и далее раз в 10 минут.
      if (Date.now() - ed.lastBackup > 600000) {
        if (ed.lastText) { await LJ.disk.backup(ed.dir, ed.lastText); await LJ.disk.prune(ed.dir); }
        ed.lastBackup = Date.now();
      }
      await LJ.disk.write(ed.dir, 'journal.html', html);
      ed.lastText = html;
      draft(false);
      if (ed.ver === v) setSt('✓ Сохранено ' + new Date().toLocaleTimeString('ru-RU'), 'ok');
    } catch (e) {
      console.error(e);
      setSt('⚠ Не сохранено: ' + (e.message || e) + ' (повтор через 5 с)', 'bad');
      ed.timer = setTimeout(save, 5000);
    } finally {
      ed.saving = false;
      if (ed.again) { ed.again = false; if (ed.ver !== v) save(); }
    }
  }

  // ---------- оглавление ----------
  function toc() {
    const nav = $('toc'); nav.innerHTML = '';
    doc.querySelectorAll(':scope>.blk').forEach(b => {
      const a = document.createElement('a');
      a.textContent = b.classList.contains('exp')
        ? q(b, '.t') + (q(b, '.d') ? ' · ' + q(b, '.d') : '')
        : 'Текст: ' + (b.querySelector('.body').innerText.replace(/\s+/g, ' ').trim().slice(0, 26) || 'пусто');
      a.onclick = () => b.scrollIntoView({ behavior: 'smooth', block: 'start' });
      nav.append(a);
    });
  }

  // ---------- события ----------
  const root = $('editor');
  root.addEventListener('input', touch);
  document.addEventListener('selectionchange', () => {
    const s = getSelection();
    if (s.rangeCount && s.anchorNode && doc.contains(s.anchorNode)) rng = s.getRangeAt(0);
  });
  root.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.closest?.('.plain')) e.preventDefault(); });

  root.addEventListener('paste', async e => {
    const t = e.target; if (!t.closest) return;
    const text = e.clipboardData.getData('text/plain');
    if (t.closest('.plain')) { e.preventDefault(); document.execCommand('insertText', false, text.replace(/\s*\n\s*/g, ' ')); return; }
    const body = t.closest('.body.ed'); if (!body) return;
    e.preventDefault();
    const f = [...e.clipboardData.files].find(f => f.type.startsWith('image/'));
    if (f) {
      try { document.execCommand('insertHTML', false, await addImage(f)); tail(body); touch(); }
      catch (err) { setSt('⚠ Картинка не записана: ' + err.message, 'bad'); }
    } else document.execCommand('insertText', false, text);
  });

  doc.addEventListener('dragover', e => e.preventDefault());
  doc.addEventListener('drop', async e => {
    const files = [...e.dataTransfer.files].filter(f => f.type.startsWith('image/'));
    if (!files.length) return;
    e.preventDefault();
    let r = document.caretRangeFromPoint(e.clientX, e.clientY);
    if (!r || !r.startContainer.parentElement?.closest('.body.ed')) return;
    for (const f of files) { rng = r; ins(await addImage(f)); r = getSelection().getRangeAt(0).cloneRange(); }
    touch();
  });
  $('fi').onchange = async e => {
    for (const f of e.target.files) { try { ins(await addImage(f)); } catch (err) { setSt('⚠ Картинка не записана: ' + err.message, 'bad'); } }
    e.target.value = ''; touch();
  };

  // клики по блокам: картинка → увеличение, × → удалить, кнопки блока
  const lb = document.querySelector('.lightbox');
  lb.onclick = () => lb.classList.remove('open');
  doc.addEventListener('click', e => {
    const t = e.target;
    if (t.matches('figure img')) { lb.firstElementChild.src = t.src; lb.classList.add('open'); return; }
    if (t.classList.contains('fx')) { t.closest('figure').remove(); touch(); return; }
    const a = t.dataset.a; if (!a) return;
    const b = t.closest('.blk'), c = b.querySelector('.cols');
    if (a === 'up' && b.previousElementSibling) b.previousElementSibling.before(b);
    if (a === 'down' && b.nextElementSibling) b.nextElementSibling.after(b);
    if (a === 'del' && confirm('Удалить блок вместе с содержимым?')) b.remove();
    if (a === 'addc') {
      c.insertAdjacentHTML('beforeend', '<div class="col"><div class="lbl ed plain" data-ph="Колонка">Новая колонка</div><div class="body ed"></div></div>');
      arm(c); tail(c.lastElementChild.querySelector('.body')); c.style.setProperty('--n', c.children.length);
    }
    if (a === 'delc' && c.children.length > 1 && confirm('Удалить последнюю колонку вместе с содержимым?')) {
      c.lastElementChild.remove(); c.style.setProperty('--n', c.children.length);
    }
    touch(); toc();
  });

  $('bar').addEventListener('mousedown', e => e.preventDefault());
  $('bar').addEventListener('click', e => {
    const t = e.target.closest('button'); if (!t) return;
    const { c, f } = t.dataset;
    if (c === 'h2') document.execCommand('formatBlock', false, document.queryCommandValue('formatBlock') === 'h2' ? 'p' : 'h2');
    else if (c) document.execCommand(c);
    if (f === 'exp') add(newExp());
    if (f === 'txt') add(mkText({ html: '<p></p>' }));
    if (f === 'img') $('fi').click();
    if (f === 'save') save();
  });
  addEventListener('keydown', e => {
    if (e.key === 'Escape') lb.classList.remove('open');
    if ((e.ctrlKey || e.metaKey) && e.key === 's' && !root.hidden) { e.preventDefault(); save(); }
  });
  addEventListener('beforeunload', e => { if (!root.hidden && (ed.saving || ed.timer && ed.ver)) { e.preventDefault(); e.returnValue = ''; } });

  // ---------- открыть / закрыть ----------
  async function open(dir, data, text) {
    ed.dir = dir; ed.lastText = text; ed.lastBackup = 0; ed.ver = 0;
    let restored = false;
    try {
      const d = JSON.parse(localStorage.getItem(DK) || 'null');
      if (d && d.project === dir.name && JSON.stringify(d.data) !== JSON.stringify(data) &&
          confirm('Найден несохранённый черновик от ' + new Date(d.at).toLocaleString('ru-RU') + '. Восстановить его?')) { data = d.data; restored = true; }
    } catch { }
    if (!restored) draft(false);
    $('start').hidden = true; root.hidden = false;
    $('pname2').textContent = dir.name;
    T.textContent = data.title; S.textContent = data.subtitle;
    doc.innerHTML = '';
    data.blocks.forEach(b => doc.append(b.type === 'experiment' ? mkExp(b) : mkText(b)));
    arm(document.querySelector('header'));
    toc(); setSt('');
    await loadImages(doc);
    if (restored) touch();
  }
  async function close() {
    if (ed.timer || ed.ver) await save();
    root.hidden = true; $('start').hidden = false; ed.dir = null;
  }
  return { open, close };
})();
